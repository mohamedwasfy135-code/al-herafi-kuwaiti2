'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

// ─── الأنواع ───
type Category = { id: number; name: string; nameEn: string; icon: string; _count?: { services: number } }
type Service = { id: number; title: string; description: string; price: number; craftsman: { name: string; rating: number }; category: { name: string } }
type Business = { id: string; name: string; businessType: string; rating: number; category: { name: string } }
type TabKey = 'explore' | 'requests' | 'orders' | 'chats'

// ─── بيانات احتياطية ───
const FALLBACK_CATEGORIES = [
  { name: 'سباكة', icon: '🔨' }, { name: 'كهرباء', icon: '⚡' }, { name: 'نجارة', icon: '🪚' },
  { name: 'تكييف', icon: '❄️' }, { name: 'دهان', icon: '🎨' }, { name: 'صيانة', icon: '🔧' },
]
const FALLBACK_SERVICES = [
  { title: 'سباكة - تركيب حنفية', price: 5 }, { title: 'كهرباء - إصلاح مفتاح', price: 8 },
  { title: 'نجارة - تجديد باب', price: 10 }, { title: 'تكييف - صيانة سنوية', price: 7 },
]
const FALLBACK_BUSINESSES = [
  { name: 'محل الأدوات المنزلية', type: 'shop' }, { name: 'شركة الصيانة العامة', type: 'company' }, { name: 'مؤسسة البناء الحديث', type: 'company' },
]
const SHOP_CATEGORIES = [
  { name: 'مواد بناء', icon: '🧱' }, { name: 'أدوات صحية', icon: '🚿' }, { name: 'كهربائيات', icon: '💡' },
  { name: 'دهانات', icon: '🎨' }, { name: 'عدد يدوية', icon: '🔧' }, { name: 'أثاث', icon: '🪑' },
]

// ─── المكون: المحتوى الرئيسي ───
function FullHomeContent({
  categories,
  services,
  businesses,
  onRequestService,
}: {
  categories: Category[]
  services: Service[]
  businesses: Business[]
  onRequestService: (serviceId?: number) => void
}) {
  const router = useRouter()

  return (
    <div>
      {/* الأقسام */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <h2 className="text-2xl font-bold mb-6">الأقسام</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {categories.length > 0
            ? categories.map((cat) => (
                <Link key={cat.id} href={`/services?category=${cat.id}`} className="flex flex-col items-center gap-2 p-4 bg-white rounded-xl border hover:shadow-md hover:border-blue-300 transition">
                  <span className="text-3xl">{cat.icon || '📂'}</span>
                  <span className="text-sm font-medium text-center">{cat.name}</span>
                  {cat._count && <span className="text-xs text-gray-400">{cat._count.services} خدمة</span>}
                </Link>
              ))
            : FALLBACK_CATEGORIES.map((cat, i) => (
                <Link key={i} href={`/services?category=${encodeURIComponent(cat.name)}`} className="flex flex-col items-center gap-2 p-4 bg-white rounded-xl border hover:shadow-md hover:border-blue-300 transition">
                  <span className="text-3xl">{cat.icon}</span>
                  <span className="text-sm font-medium text-center">{cat.name}</span>
                </Link>
              ))}
        </div>
      </section>

      {/* المحلات والشركات */}
      <section className="max-w-7xl mx-auto px-4 py-10 bg-gray-50">
        <h2 className="text-2xl font-bold mb-6">المحلات والشركات</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {SHOP_CATEGORIES.map((cat, i) => (
            <Link key={i} href={`/shops?category=${encodeURIComponent(cat.name)}`} className="flex flex-col items-center gap-2 p-4 bg-white rounded-xl border hover:shadow-md hover:border-blue-300 transition">
              <span className="text-3xl">{cat.icon}</span>
              <span className="text-sm font-medium text-center">{cat.name}</span>
            </Link>
          ))}
        </div>
        <div className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">أحدث المحلات</h3>
            <Link href="/shops" className="text-blue-600 hover:underline text-sm">عرض الكل ←</Link>
          </div>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
            {businesses.length > 0
              ? businesses.map((biz) => (
                  <div key={biz.id} className="bg-white rounded-xl border p-4 cursor-pointer hover:shadow-lg transition" onClick={() => router.push(`/shop/${biz.id}`)}>
                    <div className="flex items-center gap-3">
                      <div className="w-14 h-14 bg-blue-100 rounded-lg flex items-center justify-center text-2xl">{biz.businessType === 'company' ? '🏢' : '🏪'}</div>
                      <div className="flex-1">
                        <h3 className="font-semibold">{biz.name}</h3>
                        <p className="text-sm text-gray-500">{biz.category?.name}</p>
                        <span className="text-sm text-yellow-500">⭐ {biz.rating || 'جديد'}</span>
                      </div>
                    </div>
                  </div>
                ))
              : FALLBACK_BUSINESSES.map((b, i) => (
                  <div key={i} className="bg-white rounded-xl border p-4 cursor-pointer hover:shadow-lg transition">
                    <div className="flex items-center gap-3">
                      <div className="w-14 h-14 bg-blue-100 rounded-lg flex items-center justify-center text-2xl">{b.type === 'company' ? '🏢' : '🏪'}</div>
                      <div><h3 className="font-semibold">{b.name}</h3><span className="text-sm text-yellow-500">⭐ جديد</span></div>
                    </div>
                  </div>
                ))}
          </div>
        </div>
      </section>

      {/* الخدمات المميزة */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">الخدمات المميزة</h2>
          <Link href="/services" className="text-blue-600 hover:underline text-sm">عرض الكل ←</Link>
        </div>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {services.length > 0
            ? services.map((service) => (
                <div key={service.id} className="bg-white rounded-xl border p-4 hover:shadow-lg transition">
                  <Link href={`/service/${service.id}`}>
                    <div className="h-32 bg-gray-200 rounded-lg mb-3 flex items-center justify-center text-4xl">🔧</div>
                    <h3 className="font-semibold mb-1">{service.title}</h3>
                    <p className="text-sm text-gray-500 mb-2 line-clamp-2">{service.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-blue-600 font-bold">{service.price} د.ك</span>
                      <span className="text-sm text-gray-400">⭐ {service.craftsman?.rating || 'جديد'}</span>
                    </div>
                  </Link>
                  <button
                    onClick={() => onRequestService(service.id)}
                    className="mt-2 w-full bg-green-600 text-white py-1 rounded-lg hover:bg-green-700 text-sm"
                  >
                    اطلب الخدمة
                  </button>
                </div>
              ))
            : FALLBACK_SERVICES.map((s, i) => (
                <div key={i} className="bg-white rounded-xl border p-4 hover:shadow-lg transition">
                  <div className="h-32 bg-gray-200 rounded-lg mb-3 flex items-center justify-center text-4xl">🔧</div>
                  <h3 className="font-semibold mb-1">{s.title}</h3>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-blue-600 font-bold">{s.price} د.ك</span>
                  </div>
                  <button
                    onClick={() => onRequestService()}
                    className="mt-2 w-full bg-green-600 text-white py-1 rounded-lg hover:bg-green-700 text-sm"
                  >
                    اطلب الخدمة
                  </button>
                </div>
              ))}
        </div>
      </section>

      {/* كيف تعمل المنصة */}
      <section className="max-w-7xl mx-auto px-4 py-10 bg-gray-50">
        <h2 className="text-2xl font-bold text-center mb-8">كيف تعمل المنصة؟</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center p-6"><div className="text-4xl mb-3">🔍</div><h3 className="font-bold text-lg mb-2">ابحث عن خدمة</h3><p className="text-gray-500 text-sm">تصفح الأقسام أو ابحث عن الخدمة اللي تحتاجها</p></div>
          <div className="text-center p-6"><div className="text-4xl mb-3">🔧</div><h3 className="font-bold text-lg mb-2">اختر الحرفي</h3><p className="text-gray-500 text-sm">قارن الأسعار والتقييمات واختر الأنسب لك</p></div>
          <div className="text-center p-6"><div className="text-4xl mb-3">✅</div><h3 className="font-bold text-lg mb-2">احصل على خدمتك</h3><p className="text-gray-500 text-sm">الحرفي يوصل لموقعك وينفذ الخدمة باحترافية</p></div>
        </div>
      </section>
    </div>
  )
}

// ─── المكون الرئيسي ───
export default function HomePage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loadingUser, setLoadingUser] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [activeTab, setActiveTab] = useState<TabKey>('explore')
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)
  const [categories, setCategories] = useState<Category[]>([])
  const [services, setServices] = useState<Service[]>([])
  const [businesses, setBusinesses] = useState<Business[]>([])

  // تحميل المستخدم
  useEffect(() => {
    try {
      const stored = localStorage.getItem('sana3i_user')
      if (stored) setUser(JSON.parse(stored))
    } catch {
      localStorage.removeItem('sana3i_user')
    }
    setLoadingUser(false)
  }, [])

  // جلب البيانات
  useEffect(() => {
    fetch('/api/categories').then(r => r.json()).then(d => setCategories(d.categories || d || [])).catch(() => {})
    fetch('/api/services?limit=8').then(r => r.json()).then(d => setServices(d.services || d.data || [])).catch(() => {})
    fetch('/api/business?limit=6').then(r => r.json()).then(d => setBusinesses(d.businesses || d.data || [])).catch(() => {})
  }, [])

  // إغلاق القائمة عند الضغط خارجها
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  // ✅ الإصلاح: setUser(null) أولاً لتحديث الواجهة فوراً، ثم router.push
  const handleLogout = useCallback(() => {
    localStorage.removeItem('sana3i_user')
    setUser(null)
    router.push('/login')
  }, [router])

  // طلب الخدمة – الزائر يُحوَّل إلى /login
  const handleRequestService = useCallback((serviceId?: number) => {
    if (!user) {
      sessionStorage.setItem('redirectAfterLogin', window.location.pathname)
      router.push(`/login?redirect=${encodeURIComponent(window.location.pathname)}`)
    } else {
      router.push(`/create-request${serviceId ? `?serviceId=${serviceId}` : ''}`)
    }
  }, [user, router])

  if (loadingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-500">جارٍ التحميل...</p>
        </div>
      </div>
    )
  }

  // ✅ الإصلاح الجوهري: Header مكتوب مباشرةً في JSX وليس كمتغير أو دالة
  // هذا يضمن إعادة الرسم التلقائي عند أي تغيير في user
  return (
    <div dir="rtl" className="min-h-screen bg-gray-50">

      {/* ─── شريط التنقل ─── */}
      <header className="bg-white shadow-sm p-3 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-3">
          {user ? (
            <>
              {/* قائمة الهامبرجر */}
              <div className="relative" ref={menuRef}>
                <button
                  onClick={() => setMenuOpen(prev => !prev)}
                  className="p-2 rounded-lg hover:bg-gray-100 transition"
                  aria-label="القائمة"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                  </svg>
                </button>
                {menuOpen && (
                  <div className="absolute top-full right-0 mt-2 w-48 bg-white rounded-xl shadow-lg border overflow-hidden z-50">
                    {([
                      { key: 'explore' as TabKey, label: '🔍 استكشاف' },
                      { key: 'requests' as TabKey, label: '📋 طلباتي' },
                      { key: 'orders' as TabKey, label: '🛒 مشترياتي' },
                      { key: 'chats' as TabKey, label: '💬 محادثات' },
                    ]).map(item => (
                      <button
                        key={item.key}
                        onClick={() => {
                          if (item.key === 'chats') router.push('/chat')
                          else setActiveTab(item.key)
                          setMenuOpen(false)
                        }}
                        className={`w-full text-right px-4 py-3 text-sm hover:bg-gray-50 transition ${activeTab === item.key ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-700'}`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <Link href="/profile" className="flex items-center gap-2 hover:underline">
                <span className="bg-blue-100 text-blue-700 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">
                  {user.name?.charAt(0) || 'م'}
                </span>
                <span className="font-medium text-gray-800">مرحباً، {user.name}</span>
              </Link>
            </>
          ) : (
            <Link href="/" className="text-xl font-bold text-gray-800">الحرفي الكويتي</Link>
          )}
        </div>

        <div>
          {user ? (
            <button onClick={handleLogout} className="text-sm text-red-600 hover:underline cursor-pointer">
              خروج
            </button>
          ) : (
            // ✅ الإصلاح: Link بدلاً من <a> لضمان عمل التنقل دائماً في Next.js
            <Link
              href="/login"
              className="text-sm bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition no-underline inline-block"
            >
              تسجيل الدخول
            </Link>
          )}
        </div>
      </header>

      {/* ─── محتوى الصفحة ─── */}

      {/* واجهة العميل المسجّل */}
      {user && user.role === 'client' && (
        <div className="p-4">
          {activeTab === 'explore' && (
            <FullHomeContent
              categories={categories}
              services={services}
              businesses={businesses}
              onRequestService={handleRequestService}
            />
          )}
          {activeTab === 'requests' && (
            <div className="bg-white rounded-xl p-6 text-center text-gray-500">
              <h2 className="text-lg font-bold mb-2">طلباتي</h2>
              <p>قريباً</p>
            </div>
          )}
          {activeTab === 'orders' && (
            <div className="bg-white rounded-xl p-6 text-center text-gray-500">
              <h2 className="text-lg font-bold mb-2">مشترياتي</h2>
              <p>قريباً</p>
            </div>
          )}
          {activeTab === 'chats' && (
            <div className="bg-white rounded-xl p-6 text-center text-gray-500">
              <h2 className="text-lg font-bold mb-2">محادثات</h2>
              <p>قريباً</p>
            </div>
          )}
        </div>
      )}

      {/* واجهة الزائر (أو أي دور آخر غير client) */}
      {!user && (
        <>
          <section className="bg-gradient-to-b from-blue-600 to-blue-800 text-white py-16">
            <div className="max-w-4xl mx-auto px-4 text-center">
              <h1 className="text-4xl font-bold mb-3">الحرفي الكويتي</h1>
              <p className="text-blue-100 text-lg mb-8">اعثر على أفضل الحرفيين والمحلات في الكويت</p>
              <div className="flex gap-2 max-w-lg mx-auto">
                <input
                  type="text"
                  placeholder="ابحث عن خدمة أو محل أو حرفي..."
                  className="flex-1 bg-white text-gray-900 text-lg h-12 px-4 rounded-lg outline-none"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && searchQuery.trim())
                      router.push(`/services?search=${encodeURIComponent(searchQuery.trim())}`)
                  }}
                />
                <button
                  className="h-12 px-6 bg-yellow-500 hover:bg-yellow-600 text-black font-bold rounded-lg transition"
                  onClick={() => {
                    if (searchQuery.trim())
                      router.push(`/services?search=${encodeURIComponent(searchQuery.trim())}`)
                  }}
                >
                  بحث
                </button>
              </div>
            </div>
          </section>
          <FullHomeContent
            categories={categories}
            services={services}
            businesses={businesses}
            onRequestService={handleRequestService}
          />
        </>
      )}

      {/* أدوار أخرى (craftsman, admin, ...) */}
      {user && user.role !== 'client' && (
        <FullHomeContent
          categories={categories}
          services={services}
          businesses={businesses}
          onRequestService={handleRequestService}
        />
      )}

    </div>
  )
}
