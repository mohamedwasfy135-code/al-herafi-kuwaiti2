'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'

interface Category {
  id: number
  name: string
  icon: string | null
}

export default function AddFirstServicePage() {
  const router = useRouter()
  const fetched = useRef(false)
  const [categories, setCategories] = useState<Category[]>([])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [price, setPrice] = useState('')
  const [categoryId, setCategoryId] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [craftsmanId, setCraftsmanId] = useState<string>('')
  const [pageReady, setPageReady] = useState(false)
  const [success, setSuccess] = useState(false)

  useEffect(() => {
    if (fetched.current) return
    fetched.current = true

    async function init() {
      try {
        const [userRes, catRes] = await Promise.all([
          fetch('/api/auth/me'),
          fetch('/api/categories'),
        ])
        const userData = await userRes.json()
        const catData = await catRes.json()

        // ✅ جلب id المستخدم الحقيقي
        const uid = userData?.user?.id
        if (!uid) {
          router.push('/login')
          return
        }
        setCraftsmanId(uid)
        setCategories(catData.categories || catData || [])
      } catch {
        router.push('/login')
      } finally {
        setPageReady(true)
      }
    }

    init()
  }, [router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!title || !price || !categoryId || !craftsmanId) {
      setError('يرجى ملء جميع الحقول المطلوبة (العنوان، السعر، الفئة)')
      return
    }
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/services', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          craftsmanId,
          title,
          description,
          price: parseFloat(price),
          categoryId: parseInt(categoryId),
          isActive: true,
        }),
      })
      const data = await res.json()
      if (res.ok) {
        setSuccess(true)
      } else {
        setError(data.detail || data.error || 'فشل إنشاء الخدمة')
      }
    } catch {
      setError('تعذر الاتصال بالخادم')
    } finally {
      setLoading(false)
    }
  }

  if (!pageReady) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p>جارٍ التحميل...</p>
      </div>
    )
  }

  if (success) {
    return (
      <div dir="rtl" className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-xl mx-auto bg-white rounded-2xl shadow p-6 mt-10 text-center">
          <div className="text-6xl mb-4">🎉</div>
          <h1 className="text-2xl font-bold mb-4">تم إضافة خدمتك بنجاح!</h1>
          <p className="text-gray-600 mb-6">يمكنك الآن الدخول إلى لوحة التحكم ومتابعة عملك.</p>
          <button
            className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition"
            onClick={() => router.push('/craftsman/dashboard?firstService=1')}
          >
            الذهاب إلى لوحة التحكم
          </button>
        </div>
      </div>
    )
  }

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-xl mx-auto bg-white rounded-2xl shadow p-6 mt-10">
        <h1 className="text-2xl font-bold mb-6 text-center">أضف خدمتك الأولى</h1>
        <p className="text-gray-500 mb-6 text-center">
          اختر الفئة التي تنتمي إليها وأدخل بيانات الخدمة
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="category" className="block text-sm font-medium mb-1">الفئة *</label>
            <select
              id="category"
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
              required
            >
              <option value="">اختر فئة</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="title" className="block text-sm font-medium mb-1">عنوان الخدمة *</label>
            <input
              id="title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: تصليح مكيفات"
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
              required
            />
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium mb-1">الوصف</label>
            <input
              id="description"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="وصف مختصر للخدمة"
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label htmlFor="price" className="block text-sm font-medium mb-1">السعر (د.ك) *</label>
            <input
              id="price"
              type="number"
              step="0.1"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="20"
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
              required
            />
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg p-3 text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition disabled:opacity-50"
          >
            {loading ? 'جاري الحفظ...' : 'حفظ الخدمة'}
          </button>
        </form>

        <p className="text-center mt-4 text-sm text-gray-400">
          يمكنك تخطي هذه الخطوة لاحقًا.{' '}
          <button
            type="button"
            className="text-blue-600 underline"
            onClick={() => router.push('/craftsman/dashboard?firstService=1')}
          >
            تخطي الآن
          </button>
        </p>
      </div>
    </div>
  )
}
