import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const uid = searchParams.get('uid');

  if (!uid) {
    return NextResponse.json({ error: 'uid is required' }, { status: 400 });
  }

  // مؤقتًا: رد فارغ للتأكيد
  return NextResponse.json({ notifications: [], note: 'route works', uid });
}
