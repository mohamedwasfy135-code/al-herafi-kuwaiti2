import { NextRequest, NextResponse } from 'next/server'
import { Pool } from 'pg'

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: true } : { rejectUnauthorized: false },
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { clientId, craftsmanId, serviceType, description, estimated_price, status } = body

    if (!clientId || !craftsmanId || !serviceType) {
      return NextResponse.json(
        { error: 'clientId, craftsmanId, and serviceType are required' },
        { status: 400 }
      )
    }

    const query = `
      INSERT INTO requests (client_id, craftsman_id, service_type, description, estimated_price, status, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, NOW())
      RETURNING *
    `
    const values = [
      clientId,
      craftsmanId,
      serviceType,
      description || '',
      parseFloat(estimated_price) || 0,
      status || 'pending',
    ]

    const result = await pool.query(query, values)

    return NextResponse.json({ request: result.rows[0] }, { status: 201 })
  } catch (error) {
    console.error('Create request error:', error)
    return NextResponse.json(
      { error: 'Failed to create request' },
      { status: 500 }
    )
  }
}