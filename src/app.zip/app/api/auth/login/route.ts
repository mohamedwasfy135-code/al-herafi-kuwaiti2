import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createSessionToken, setSessionCookie } from '@/lib/auth'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phone, email, password, loginType } = body

    // Log only login type (no sensitive data)
    console.log('[LOGIN] Attempt:', { loginType })

    if (!password) {
      return NextResponse.json(
        { error: 'كلمة المرور مطلوبة' },
        { status: 400 }
      )
    }

    // Business sub-user login (seller/accountant)
    if (loginType === 'business_user') {
      if (!phone && !email) {
        return NextResponse.json(
          { error: 'رقم الجوال أو البريد الإلكتروني مطلوب' },
          { status: 400 }
        )
      }

      // Find BusinessUser by phone or email
      const businessUser = await db.businessUser.findFirst({
        where: {
          OR: [
            ...(phone ? [{ phone }] : []),
            ...(email ? [{ email }] : []),
          ],
          isActive: true,
        },
        include: {
          business: {
            select: { id: true, name: true },
          },
        },
      })

      if (!businessUser) {
        return NextResponse.json(
          { error: 'المستخدم غير موجود أو الحساب معطل' },
          { status: 401 }
        )
      }

      if (businessUser.password !== password) {
        return NextResponse.json(
          { error: 'كلمة المرور غير صحيحة' },
          { status: 401 }
        )
      }

      // Create JWT token for business sub-user
      const token = await createSessionToken({
        userId: businessUser.id,
        role: 'business',
        name: businessUser.name,
      })

      const responseJson = {
        success: true,
        user: {
          id: businessUser.id,
          name: businessUser.name,
          phone: businessUser.phone,
          email: businessUser.email,
          role: 'business',
          businessId: businessUser.businessId,
          businessName: businessUser.business.name,
          businessRole: businessUser.role,
          permissions: businessUser.permissions,
        },
      }

      const response = NextResponse.json(responseJson)
      setSessionCookie(response, token)

      return response
    }

    // Regular owner login (existing logic)
    if (!phone) {
      return NextResponse.json(
        { error: 'رقم الجوال مطلوب' },
        { status: 400 }
      )
    }

    const user = await db.user.findFirst({
      where: { phone: phone },
      select: {
        id: true,
        name: true,
        phone: true,
        password: true,
        role: true,
        avatarUrl: true,
      }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'رقم الجوال أو كلمة المرور غير صحيحة' },
        { status: 401 }
      )
    }

    if (user.password !== password) {
      return NextResponse.json(
        { error: 'رقم الجوال أو كلمة المرور غير صحيحة' },
        { status: 401 }
      )
    }

    // إنشاء JWT token
    const token = await createSessionToken({
      userId: user.id,
      role: user.role,
      name: user.name || '',
    })

    // إنشاء الاستجابة وضبط الكوكي عليها مباشرة
    const responseJson: Record<string, unknown> = {
      success: true,
      user: {
        id: user.id,
        name: user.name,
        phone: user.phone,
        role: user.role,
        avatarUrl: user.avatarUrl,
      }
    }

    // If business user, include the business ID
    if (user.role === 'business') {
      const business = await db.business.findFirst({
        where: { ownerId: user.id },
        select: { id: true, name: true }
      })
      if (business) {
        (responseJson.user as Record<string, unknown>).businessId = business.id
        ;(responseJson.user as Record<string, unknown>).businessName = business.name
      }
    }

    const response = NextResponse.json(responseJson)
    setSessionCookie(response, token)

    return response

  } catch (error: any) {
    console.error('[LOGIN] Error:', error?.message || error)

    return NextResponse.json(
      { error: 'حدث خطأ في الخادم. حاول مرة أخرى.' },
      { status: 500 }
    )
  }
}
