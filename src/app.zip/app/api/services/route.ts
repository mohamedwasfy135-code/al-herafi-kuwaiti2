import { NextRequest, NextResponse } from 'next/server'
import { Pool } from 'pg'

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false, // ضروري لـ Supabase
  },
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const categoryId = searchParams.get('categoryId') || ''
    const search = searchParams.get('search') || ''
    const craftsmanId = searchParams.get('craftsmanId') || ''
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const skip = (page - 1) * limit

    let where = 'WHERE s.is_active = true'
    const values: any[] = []

    if (categoryId) {
      values.push(parseInt(categoryId))
      where += ` AND s.category_id = $${values.length}`
    }

    if (craftsmanId) {
      values.push(craftsmanId)
      where += ` AND s.craftsman_id = $${values.length}`
    }

    if (search) {
      const idx = values.length + 1
      values.push(`%${search}%`, `%${search}%`)
      where += ` AND (s.title ILIKE $${idx} OR s.description ILIKE $${idx + 1})`
    }

    const servicesQuery = `
      SELECT 
        s.id, s.title, s.description, s.price, s.images,
        s.craftsman_id AS "craftsmanId",
        row_to_json(u.*) AS craftsman,
        CASE WHEN c.id IS NOT NULL THEN row_to_json(c.*) ELSE NULL END AS category
      FROM services s
      JOIN users u ON s.craftsman_id = u.id
      LEFT JOIN categories c ON s.category_id = c.id
      ${where}
      ORDER BY s.created_at DESC
      LIMIT $${values.length + 1} OFFSET $${values.length + 2}
    `
    values.push(limit, skip)

    const countQuery = `SELECT COUNT(*) FROM services s ${where}`
    const countValues = values.slice(0, values.length - 2)

    const [servicesResult, countResult] = await Promise.all([
      pool.query(servicesQuery, values),
      pool.query(countQuery, countValues),
    ])

    const total = parseInt(countResult.rows[0].count, 10)

    return NextResponse.json({
      data: servicesResult.rows,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching services:', error)
    return NextResponse.json({
      data: [],
      pagination: { page: 1, limit: 20, total: 0, totalPages: 0 },
    })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { craftsmanId, title, description, price, categoryId, isActive } = body

    if (!craftsmanId || !title || price === undefined) {
      return NextResponse.json(
        { error: 'الحقول المطلوبة: craftsmanId, title, price' },
        { status: 400 }
      )
    }

    const insertQuery = `
      INSERT INTO services (craftsman_id, title, description, price, category_id, is_active, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, NOW())
      RETURNING *
    `
    const values = [
      craftsmanId,
      title,
      description || null,
      parseFloat(price),
      categoryId ? parseInt(categoryId) : null,
      isActive !== undefined ? Boolean(isActive) : true,
    ]

    const result = await pool.query(insertQuery, values)
    const newService = result.rows[0]

    return NextResponse.json({ service: newService }, { status: 201 })
  } catch (error: any) {
    console.error('❌ Error creating service:', error)
    const detail = error.message || String(error)
    return NextResponse.json(
      { error: 'فشل إنشاء الخدمة', detail },
      { status: 500 }
    )
  }
}
